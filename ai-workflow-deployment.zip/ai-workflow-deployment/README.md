# AI Workflow Deployment – AAVAIL Churn Prediction

Full ML pipeline with EDA, API, Docker, and Monitoring.
